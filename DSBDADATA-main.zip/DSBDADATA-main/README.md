**heart** : https://www.kaggle.com/datasets/pritsheta/heart-attack



**air quality** : https://www.kaggle.com/datasets/uditmistry/india-air-quality-data?rvi=1




**visualisation 2&3** : https://www.kaggle.com/datasets/dharanireddy/heart-disease?rvi=1





**facebook** : https://www.kaggle.com/datasets/mrsohelranapro/facebook-metrics-dataset?rvi=1







**forestfire** : https://www.kaggle.com/datasets/mcbracket/forestfires






**tableau adult** : https://www.kaggle.com/datasets/lovishbansal123/adult-census-income







**tableau iris** : https://www.kaggle.com/datasets/jillanisofttech/iris-dataset-uci










